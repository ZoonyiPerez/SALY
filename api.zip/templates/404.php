<?php $this->layout('layout', ['title' => 'Page not found']) ?>

    <div id="fb-root"></div>
	<script async defer crossorigin="anonymous"
		src="https://connect.facebook.net/es_LA/sdk.js#xfbml=1&version=v15.0&appId=497938065093299&autoLogAppEvents=1"
		nonce="ZwGtULEe"></script>
	<div class="navbar">
		<div class="navbar-inner">
			<div class="container"><a class="brand" href="#"><img alt="Logo" src="images/logoHorizontalBlanco.png" />
					<!-- This is website logo --> </a> <!-- Navigation button, visible on small resolution --><button
					class="btn btn-navbar" data-target=".nav-collapse" data-toggle="collapse" type="button">
					<img alt="Icono Menu" src="imagenes/Iconos Redes/menu.png" width="30" height="30" />
				</button>
                	<!-- Main navigation -->
				<div class="nav-collapse collapse pull-right">
					<ul class="nav" id="top-navigation">
						<li class="active"><a href="#home">Inicio</a></li>
						<li><a href="#contact">Contacto</a></li>
					</ul>
				</div>
            </div>
        </div>
    </div>
	<!-- End main navigation -->
    <div id="home">
        <h2>Page not found</h2>
    </div>
