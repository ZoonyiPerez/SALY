<?php include '../page.php'; ?>
